CONSOLE CMD
cd E:\Procon\118991\3
java -jar pdfMetadados.jar

ou

 java -jar E:\Procon\118991\4\pdfMetadados.jar E:\\Projetos\\teste-metadados\\Processos-Corrente-Novo14 Processos-Corrente E:\\Projetos\\teste-metadados1\\Processos-Corrente-Novo14  
 
 
```

```

Arquivos de Log produzidos caminho fixo:
C:\temp\metadadosLog\logMetadados.txt
C:\temp\metadadosLog\logTotalFiles.txt
```

* Info

parametros
<diretório absoluto PDFS originais> <palavras-chave> <diretório Saida PDFS metadados> 

diretório absoluto PDFS originais:  Opcões Grisoni - precisa verificar 
Processos-Arquivo Cambui
Processos-Arquivo Geral
Processos-Corrente
Processos-Intercorrente
Processos-Multas
Processos-Prescritos. FEITO
Processos-Quinquenal

<palavras-chave> seria o metadados da categoria Palavras-chave

<diretório Saida PDFS metadados> diretorio onde escrever os pdfs de saida
